HBT ANUJ — student learning companion

HOW TO RUN
1. Open index.html in a modern browser. The responsive website works as a standalone front-end demo.
2. Navigation, mood check-in, notes/practice templates, and chat UI are interactive.

IMPORTANT AI INTEGRATION NOTE
This starter currently uses a built-in demonstration answer generator when no backend is connected. It does not claim to be a live AI model. To enable genuinely deep, current, question-specific answers, implement a secure backend endpoint POST /api/chat that accepts JSON { message, context, history } and returns JSON { answer }. Keep your AI provider API key on the server in an environment variable; never place secret keys in index.html or browser JavaScript. The front end already attempts to call /api/chat and falls back to demo content if the endpoint is unavailable.

WELLBEING
The supportive check-in is not therapy or emergency care. It encourages trusted human support and includes India emergency/Tele-MANAS contact guidance for crisis language.
